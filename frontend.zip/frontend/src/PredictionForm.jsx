// src/PredictionForm.jsx

import { useState } from 'react';

// This component receives a function `onPrediction` from its parent (App.jsx)
// to pass the prediction result back up.
function PredictionForm({ onPrediction }) {
  // 1. Use a single state object to hold all feature values
  const [features, setFeatures] = useState({
    displacement_cm: 2.0,
    strain: 0.01,
    pore_pressure_kPa: 40.0,
    rainfall_mm: 10.0,
    temperature_c: 25.0,
    slope_angle: 45.0,
    image_crack_score: 0.5,
  });

  // 2. A function to handle changes in any of the sliders
  const handleSliderChange = (e) => {
    const { name, value } = e.target;
    setFeatures(prevFeatures => ({
      ...prevFeatures,
      [name]: parseFloat(value),
    }));
  };

  // 3. A function to handle the form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the page from reloading

    // Call the API
    fetch("http://127.0.0.1:8000/predict", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(features),
    })
    .then(response => response.json())
    .then(data => {
      onPrediction(data); // Pass the prediction data to the parent component
    })
    .catch(error => {
      console.error("Error making prediction:", error);
      onPrediction({ error: "Failed to get prediction." });
    });
  };

  return (
    <form onSubmit={handleSubmit} className="prediction-form">
      <h3>Input Parameters</h3>
      <div className="form-grid">
        {/* We map over the features to create a slider for each one */}
        {Object.keys(features).map(key => (
          <div key={key} className="form-group">
            <label>{key.replace(/_/g, ' ')}: {features[key]}</label>
            <input
              type="range"
              name={key}
              value={features[key]}
              onChange={handleSliderChange}
              // Set appropriate min/max/step values for each slider
              min={0}
              max={key === 'slope_angle' ? 60 : (key === 'strain' ? 0.02 : 50)}
              step={key === 'strain' ? 0.001 : 0.1}
            />
          </div>
        ))}
      </div>
      <button type="submit" className="predict-button">Predict Risk</button>
    </form>
  );
}

export default PredictionForm;
